//
//  FavoriteMoviesViewController.swift
//  movieApp
//
//  Created by Beibarys Tulenov on 04.11.2021.
//

import UIKit

class FavoriteMoviesViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    private var movies: [MovieEntity.Movie] = [] {
        didSet {
            if movies.count != oldValue.count {
                tableView.reloadData()
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: MovieCell.identifier, bundle: Bundle(for: MovieCell.self)), forCellReuseIdentifier: MovieCell.identifier)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        movies = CoreDataManager.shared.allMovies()
    }
    

}

extension FavoriteMoviesViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movies.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: MovieCell.identifier, for: indexPath) as! MovieCell
        cell.movie = movies[indexPath.row]
        cell.delegate = self
        return cell
    }
    
}

extension FavoriteMoviesViewController: RefreshFavorite {
    func refreshFavorite() {
        movies = CoreDataManager.shared.allMovies()
        tableView.reloadData()
    }
    
    
}
