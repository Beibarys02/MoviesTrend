//
//  MovieDetailsViewController.swift
//  movieApp
//
//  Created by Beibarys Tulenov on 04.11.2021.
//

import UIKit
import Alamofire
import Kingfisher

class MovieDetailsViewController: UIViewController {
    
    public var movieId: Int? {
        didSet {
            if let movieId = movieId {
                MovieDetailsURL = "https://api.themoviedb.org/3/movie/\(movieId)?api_key=29c31f98ca775e17dd17720db9b412b3&language=en-US"
            }
        }
    }
    private var movieDetails: MovieDescriptionEntity? {
        didSet {
            if let movieDetails = movieDetails {
                let posterURL = URL(string: "https://image.tmdb.org/t/p/w500" + (movieDetails.poster ?? ""))
                posterImageView.kf.setImage(with: posterURL)
                overviewLabel.text = movieDetails.overview
                releaseDateLabel.text = movieDetails.releaseDate
                titleLabel.text = movieDetails.title
                self.title = movieDetails.title
                ratingLabel.text = "\(movieDetails.rating)"
            }
        }
    }
    private var MovieDetailsURL: String = "https://api.themoviedb.org/3/movie/1?api_key=29c31f98ca775e17dd17720db9b412b3&language=en-US"
    
    var delegate: RefreshFavorite?

    @IBOutlet weak var overviewLabel: UITextView!
    @IBOutlet weak var releaseDateLabel: UILabel!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var ratingLabel: UILabel!
    @IBOutlet weak var ratingContainerView: UIView!
    @IBOutlet weak var favoriteButton: UIButton!
    @IBOutlet weak var posterImageView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()

        ratingContainerView.layer.cornerRadius = 20
        ratingContainerView.layer.masksToBounds = true
        posterImageView.backgroundColor =  .systemTeal
        
        getMovieDetails()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let movieId = movieId {
            if let _ = CoreDataManager.shared.findMovie(with: movieId) {
                favoriteButton.setImage(UIImage(named: "starFilled"), for: .normal)
            } else {
                favoriteButton.setImage(UIImage(named: "star"), for: .normal)
            }
        }
    }
    
    @IBAction func favoriteButtonPressed(_ sender: Any) {
        if let movieId = movieId {
            if let _ = CoreDataManager.shared.findMovie(with: movieId) {
                CoreDataManager.shared.deleteMovie(with: movieId)
                favoriteButton.setImage(UIImage(named: "star"), for: .normal)
                delegate?.refreshFavorite()
            } else {
                if let details = movieDetails {
                    CoreDataManager.shared.addMovie(details)
                    favoriteButton.setImage(UIImage(named: "starFilled"), for: .normal)
                }
            }
        }
    }
}

extension MovieDetailsViewController {
    private func getMovieDetails() {
        AF.request(MovieDetailsURL, method: .get, parameters: [:]).responseJSON { [weak self] (response) in
            switch response.result {
            case .success:
                if let data = response.data {
                    do {
                        let movieDetailsJSON = try JSONDecoder().decode(MovieDescriptionEntity.self, from: data)
                        self?.movieDetails = movieDetailsJSON
                    } catch {
                        print(error)
                    }
                }
            case .failure:
                print("MovieDetailsURL failed to send JSON")
            }
        }
    }
}
