//
//  ViewController.swift
//  movieApp
//
//  Created by Beibarys Tulenov on 19.05.2021.
//

import UIKit
import Alamofire

class TrendingMoviesViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    private let TrendingMoviesURL = "https://api.themoviedb.org/3/trending/movie/week?api_key=29c31f98ca775e17dd17720db9b412b3"
    private var movies: [MovieEntity.Movie] = [MovieEntity.Movie]() {
        didSet {
            tableView.reloadData()
        }
    }
    
    private var pageNumber: Int = 1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.contentInset = UIEdgeInsets(top: 16, left: 0, bottom: 0, right: 0)
        tableView.separatorStyle = .none
        tableView.register(UINib(nibName: MovieCell.identifier, bundle: Bundle(for: MovieCell.self)), forCellReuseIdentifier: MovieCell.identifier)
        
        getTrendingMovies()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableView.reloadData()
    }

}

//MARK: - Internal Functions
extension TrendingMoviesViewController {
    
    private func getTrendingMovies(_ page: Int? = nil) {
        var params: [String: Any] = [:]
        if let page = page {
            params["page"] = page
        }
        
        AF.request(TrendingMoviesURL, method: .get, parameters: params).responseJSON { [weak self] (response) in
            switch response.result {
            case .success:
                if let data = response.data {
                    do {
                        let moviesJSON = try JSONDecoder().decode(MovieEntity.self, from: data)
                        self?.movies += moviesJSON.movies
                    } catch {
                        print(error)
                    }
                    
                }
            case .failure:
                print("TrendingMoviesURL failed to send JSON")
            }
        }
    }
}

//MARK: - UITableViewDelegate
extension TrendingMoviesViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        if let vc = storyboard.instantiateViewController(withIdentifier: "MovieDetailsViewController") as? MovieDetailsViewController {
            vc.movieId = movies[indexPath.row].id
            vc.delegate = self
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let currentOffset = scrollView.contentOffset.y
        let maximumOffset = scrollView.contentSize.height - scrollView.frame.size.height
        let delta = maximumOffset - currentOffset
        
        if (delta >= 10 && delta < 200) {
            pageNumber += 1
            getTrendingMovies(pageNumber)
        }
    }
}

//MARK: - UITableViewDataSource
extension TrendingMoviesViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movies.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: MovieCell.identifier, for: indexPath) as! MovieCell
        cell.movie = movies[indexPath.row]
        cell.delegate = self
        return cell
    }
}

extension TrendingMoviesViewController: RefreshFavorite {
    func refreshFavorite() {
        tableView.reloadData()
    }
}
