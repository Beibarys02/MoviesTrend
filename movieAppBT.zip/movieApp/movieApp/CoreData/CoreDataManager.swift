//
//  CoreDataManager.swift
//  movieApp
//
//  Created by  Beibarys Tulenov on 04.11.2021.
//

import Foundation
import CoreData

class CoreDataManager {
    
    static let shared = CoreDataManager()
    
    private init() {}
    
    private lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "LocalDBModel")
        container.loadPersistentStores { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        }
        return container
    }()
    
    func save() {
        let context = persistentContainer.viewContext
        do {
            try context.save()
        } catch {
            print(error)
        }
    }
    
    func addMovie(_ movie: MovieEntity.Movie) {
        let context = persistentContainer.viewContext
        
        context.perform {
            let newMovie = MovieDBEntity(context: context)
            newMovie.id = Int64(movie.id)
            newMovie.title = movie.title
            newMovie.poster = movie.poster
            newMovie.releaseDate = movie.releaseDate
            newMovie.rating = movie.rating ?? 0
        }
        save()
    }
    
    func addMovie(_ movie: MovieDescriptionEntity) {
        let context = persistentContainer.viewContext
        
        context.perform {
            let newMovie = MovieDBEntity(context: context)
            newMovie.id = Int64(movie.id)
            newMovie.title = movie.title
            newMovie.releaseDate = movie.releaseDate
            newMovie.rating = movie.rating
            newMovie.poster = movie.poster
        }
        save()
    }
    
    func findMovie(with id: Int) -> MovieDBEntity? {
        let requestResult: NSFetchRequest<MovieDBEntity> = MovieDBEntity.fetchRequest()
        let context = persistentContainer.viewContext
        
        requestResult.predicate = NSPredicate(format: "id == %d", id)
        
        do {
            let movies = try context.fetch(requestResult)
            if movies.count > 0 {
                assert(movies.count == 1, "Duplicate found in DB!")
                return movies[0]
            }
        }
        catch {
            print(error)
        }
        
        return nil
    }
    
    func deleteMovie(with id: Int) {
        let context = persistentContainer.viewContext
        if let movie = findMovie(with: id) {
            context.delete(movie)
        }
        save()
    }
    
    func allMovies() -> [MovieEntity.Movie] {
        let requestResult: NSFetchRequest<MovieDBEntity> = MovieDBEntity.fetchRequest()
        let context = persistentContainer.viewContext
        
        let movies = try? context.fetch(requestResult)
        return movies?.map({MovieEntity.Movie(movie: $0)}) ?? []
    }
}
