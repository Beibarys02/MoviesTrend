//
//  MovieDBEntity.swift
//  movieApp
//
//  Created by Beibarys Tulenov on 04.11.2021.
//

import Foundation
import CoreData

class MovieDBEntity: NSManagedObject {
    
}
