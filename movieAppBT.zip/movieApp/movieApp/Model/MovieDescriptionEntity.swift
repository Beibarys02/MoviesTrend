//
//  MovieDescriptionEntity.swift
//  movieApp
//
//  Created by Beibarys Tulenov on 04.11.2021.
//

import Foundation

struct MovieDescriptionEntity: Decodable {
    let id: Int
    let title: String
    let releaseDate: String
    let poster: String?
    let rating: Double
    let overview: String
    
    enum CodingKeys: String, CodingKey {
        case id
        case title = "original_title"
        case overview
        case releaseDate = "release_date"
        case poster = "backdrop_path"
        case rating = "vote_average"
    }
}
