//
//  MovieEntity.swift
//  movieApp
//
//  Created by Beibarys Tulenov on 04.11.2021.
//

import Foundation

struct MovieEntity: Decodable {
    let movies: [Movie]
    
    enum CodingKeys: String, CodingKey {
        case movies = "results"
    }
    
    struct Movie: Decodable {
        let id: Int
        let title: String?
        let releaseDate: String?
        let poster: String?
        let rating: Double?
        
        enum CodingKeys: String, CodingKey {
            case id
            case title = "original_title"
            case releaseDate = "release_date"
            case poster = "poster_path"
            case rating = "vote_average"
        }
        
        init(movie: MovieDBEntity) {
            self.id = Int(movie.id)
            self.title = movie.title
            self.releaseDate = movie.releaseDate
            self.poster = movie.poster
            self.rating = movie.rating
        }
    }
}
