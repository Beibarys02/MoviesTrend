//
//  MovieCell.swift
//  movieApp
//
//  Created by Beibarys Tulenov on 04.11.2021.
//

import UIKit
import Kingfisher

protocol RefreshFavorite {
    func refreshFavorite()
}

class MovieCell: UITableViewCell {

    public static let identifier: String = "MovieCell"
    
    @IBOutlet private weak var releaseDateLabel: UILabel!
    @IBOutlet private weak var movieTitleLabel: UILabel!
    @IBOutlet private weak var posterImageView: UIImageView!
    @IBOutlet private weak var ratingContainerView: UIView!
    @IBOutlet weak var favoriteButton: UIButton!
    @IBOutlet private weak var ratingLabel: UILabel!
    
    var delegate: RefreshFavorite?
    
    public var movie: MovieEntity.Movie? {
        didSet {
            if let movie = movie {
                let posterURL = URL(string: "https://image.tmdb.org/t/p/w500" + (movie.poster ?? ""))
                posterImageView.kf.setImage(with: posterURL)
                ratingLabel.text = "\(movie.rating ?? 0)"
                movieTitleLabel.text = movie.title
                releaseDateLabel.text = movie.releaseDate
                
                if let _ = CoreDataManager.shared.findMovie(with: movie.id) {
                    favoriteButton.setImage(UIImage(named: "starFilled"), for: .normal)
                } else {
                    favoriteButton.setImage(UIImage(named: "star"), for: .normal)
                }
            }
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        selectionStyle = .none
        ratingContainerView.layer.cornerRadius = 20
        ratingContainerView.layer.masksToBounds = true
        posterImageView.layer.cornerRadius = 20
        posterImageView.layer.masksToBounds = true
        posterImageView.backgroundColor = .systemTeal
    }
    
    @IBAction func favoriteButtonPressed(_ sender: Any) {
        if let movie = movie {
            if let _ = CoreDataManager.shared.findMovie(with: movie.id) {
                CoreDataManager.shared.deleteMovie(with: movie.id)
                favoriteButton.setImage(UIImage(named: "star"), for: .normal)
                delegate?.refreshFavorite()
            } else {
                CoreDataManager.shared.addMovie(movie)
                favoriteButton.setImage(UIImage(named: "starFilled"), for: .normal)
            }
        }
    }
}
